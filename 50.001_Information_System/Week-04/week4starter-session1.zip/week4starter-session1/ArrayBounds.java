public class ArrayBounds {
    public static void main (String[] args) {
        System.out.println("In Array Bounds demo. ");
        int[] a = {1,2,3};
        System.out.println(a[3]);
        }
    }
}