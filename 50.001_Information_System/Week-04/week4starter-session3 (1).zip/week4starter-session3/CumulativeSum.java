public class CumulativeSum {
   public static void main (String[] args) {
       int d[] = {2,3,1,5,6,2,7};
       
       cumulativeSum(d, 1);
       // Insert your code here
   }

    public static void cumulativeSum(int data[], int n) {
    

    // Insert your code here

        
    }

}
