public class TestFib {
    public static void main (String[] args) {
        System.out.println("In TestFib");
        int k = 5;
        System.out.println("Fibonacci of " + k + " is " + rfib(k));
    }
    public static int rfib (int n) {
        // Enter code here
    }
}
