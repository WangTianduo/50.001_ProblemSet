public class TestEndX {
    public static void main (String[] args) {
        System.out.println("In TestEndX");

        //String s = "kkix";
        String s = "kickback";
        System.out.println (endX(s));
    }
    public static String endX(String s) {
        // enter code here

        }
}
