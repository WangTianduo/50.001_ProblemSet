import java.lang.Math;


public class RecurMulti {
    public static void main(String[] args) {
        System.out.println(multiply(4, 7));
        System.out.println(multiply(0,7));
        System.out.println(multiply(4,0));

    }

    public static int multiply(int i, int j) {
        
    }

}