package com.example;

/**
 * Created by jit_biswas on 10/2/2017.
 */
public class TestMoveInStars {
    public static void main (String[] args) {
        System.out.println("In TestMoveInStars");

        String s = "Massachussetts";
        String s1 = "anna";
        System.out.println (moveInStars(s1));
    }
    public static String moveInStars(String s) {
        // Enter code here
    }
}
