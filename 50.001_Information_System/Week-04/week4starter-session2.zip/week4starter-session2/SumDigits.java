public class SumDigits {
     public static void main (String[] args) {
            int number = 54321;

            // Input your codes here.
            // Suggested solution plan. Handle negative 
            // case first, then invoke sumDigits(number)

            }
        
        public static int sumDigits(int i) {
             // Input your codes here


        }
}


