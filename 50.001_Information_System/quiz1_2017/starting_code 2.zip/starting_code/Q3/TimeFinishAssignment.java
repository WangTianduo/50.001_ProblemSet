
public class TimeFinishAssignment {

    public static void main(String[] args) {
        ArrayList<Integer> listOfAssignment = new ArrayList<>();
        listOfAssignment.add(6);
        listOfAssignment.add(7);
        listOfAssignment.add(8);
        listOfAssignment.add(9);
        listOfAssignment.add(10);

        System.out.println(computeTimeFinish(listOfAssignment));
        // output: 15

    }



    public static int computeTimeFinish(ArrayList<Integer> l) {
       // TODO: implement computeTimeFinish method
    }



}
