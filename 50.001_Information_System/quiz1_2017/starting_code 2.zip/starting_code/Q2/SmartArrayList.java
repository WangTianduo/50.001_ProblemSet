
public class SmartArrayList {
    private static final int INIT_CAPACITY = 2;
    private int size=0;  // no of element stored
    private String[] data = new String[INIT_CAPACITY]; // where the element stored


    public SmartArrayList() {

    }

    public void add(int index, String s) {
        // check 0<= index <= size
        // when index == size, append to the end
        // TODO: IMPLEMENT THE METHOD


    }

    public void add(String s) {
        // TODO: IMPLEMENT THE METHOD

    }

    public String get(int index) {
        // TODO: IMPLEMENT THE METHOD


    }

    public void set(int index, String s){
        // TODO: IMPLEMENT THE METHOD

    }

    public void remove(int index) {
        // TODO: IMPLEMENT THE METHOD

    }

    @Override
    public String toString(){
        // TODO: IMPLEMENT THE METHOD

    }


}
