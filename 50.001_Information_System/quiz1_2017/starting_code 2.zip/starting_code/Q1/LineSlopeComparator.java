
public class LineSlopeComparator  {
     //TODO: IMPLEMENT CLASS 



}
